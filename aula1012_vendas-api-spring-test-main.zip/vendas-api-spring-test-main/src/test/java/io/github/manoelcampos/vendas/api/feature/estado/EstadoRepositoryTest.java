package io.github.manoelcampos.vendas.api.feature.estado;

import io.github.manoelcampos.vendas.api.feature.estado.EstadoRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.dao.DataIntegrityViolationException;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class EstadoRepositoryTest {
    @Autowired
    private EstadoRepository repository;

    @Test
    void findById() {
        final long id = 1;
        var estado =  repository.findById(id).orElseThrow();
        final var nomeEsperado = "São Paulo";
        assertEquals(nomeEsperado, estado.getDescricao());
    }

    @Test
    void deleteById() {
        final long id = 1;
        assertThrows(DataIntegrityViolationException.class, () -> {
            repository.deleteById(id);
            repository.flush();
        });
    }
}