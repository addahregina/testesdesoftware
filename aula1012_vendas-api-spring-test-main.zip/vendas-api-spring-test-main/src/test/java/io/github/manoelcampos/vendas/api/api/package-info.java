/**
 * Testes de API com o uso do {@link org.springframework.test.web.reactive.server.WebTestClient}.
 */
package io.github.manoelcampos.vendas.api.api;
