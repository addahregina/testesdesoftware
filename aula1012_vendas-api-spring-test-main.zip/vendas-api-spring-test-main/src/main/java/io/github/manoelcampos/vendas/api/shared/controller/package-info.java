/**
 * Classes base para implementação de {@link org.springframework.web.bind.annotation.RestController}.
 */
package io.github.manoelcampos.vendas.api.shared.controller;
