/**
 * Pacote base para implementação de classes de negócio, que podem ser {@link jakarta.persistence.Entity} ou não.
 */
package io.github.manoelcampos.vendas.api.model;
