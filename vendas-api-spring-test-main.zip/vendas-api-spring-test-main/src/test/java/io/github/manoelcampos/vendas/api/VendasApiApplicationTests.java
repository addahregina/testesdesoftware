package io.github.manoelcampos.vendas.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Uma classe de testes para verificar se a aplicação Spring está sendo inicializada corretamente.
 */
@SpringBootTest
class VendasApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
