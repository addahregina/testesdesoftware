package com.sistemabancario.model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

import static org.junit.jupiter.api.Assertions.*;

public class ContaTest {

    //independentemente do tipo, os valores devem ser enviados entre aspas
    @ParameterizedTest
    @CsvSource({
            "500.1, 600.2, 1100.3", //se o saldo for x e o limite y o resultado deve ser z
            "500.10, 600.10, 1100.50",
            "500, 600, 1100", //se o saldo for x e o limite y o resultado deve ser z
            "500, 0, 500",
            "0, 600, 600",
            "0, 0, 0"
    })
    void getSaldoTotal(double saldo, double limite, double esperado) {

        final var conta = new Conta();
        conta.setSaldo(saldo);
        conta.setLimite(limite);
        final double obtido =  conta.getSaldoTotal();
        assertEquals(esperado, obtido, 0.001); //delta -> margem de erro
    }


}
