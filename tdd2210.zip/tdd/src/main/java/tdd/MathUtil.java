package tdd;

public class MathUtil {

    public static int mdc(int a, int b) {
        return -1;
    }

}
