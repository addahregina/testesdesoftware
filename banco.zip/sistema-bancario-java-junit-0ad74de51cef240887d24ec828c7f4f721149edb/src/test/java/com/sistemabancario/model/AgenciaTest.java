package com.sistemabancario.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class AgenciaTest {
    @Test
    void novaAgencia(){
        final var banco = new Banco();
        final var agencia = new Agencia(banco);

    }

    @Test
    void novaAgenciaBancoNulo(){
        assertThrows(
                NullPointerException.class,
                () -> new Agencia(null);
        );
    }
}